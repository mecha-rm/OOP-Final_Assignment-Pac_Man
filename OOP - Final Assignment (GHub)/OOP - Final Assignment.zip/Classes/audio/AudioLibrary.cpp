
// a file creates all audio for the game. Taken from Ampersand V's game.
#include "audio/AudioLibrary.h"

Music AudioLibrary::bgm1 = Music("2-32 PAC-MAN 1"); // PAC-MAN
Music AudioLibrary::bgm2 = Music("1-31 PAC-MAN (Club Mix)"); // PAC-MAN

